package javafxproject.Controller;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;

/**
 *
 * @author belbeni
 */
public class WarningController implements Initializable{

    @Override
    public void initialize(URL location, ResourceBundle resources){
        
    }
    
     @FXML
    private void closeApp(ActionEvent event){
        System.exit(0);
    }
}
