package javafxproject.Controller;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author belbeni
 */
public class CreditsController implements Initializable{

    @Override
    public void initialize(URL location, ResourceBundle resources) {    
    }
    
    @FXML
    private void TornaPrincipalMenu(ActionEvent event) throws Exception{
        Parent root = FXMLLoader.load(getClass().getResource("/javafxproject/fxml/PrincipalMenu.fxml"));
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root,600,650);
            window.setScene(scene);
            window.show();
    }
         
    @FXML
    private void closeApp(ActionEvent event){
        System.exit(0);
    }
    
}