package javafxproject.Controller;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import javafxproject.Domanda;

public class EditorDomandeController {

	@FXML
	private TextArea lblQuestion;

	@FXML
	private TextField lblOptionA;

	@FXML
	private RadioButton radioButtonA;

	@FXML
	private TextField lblOptionB;

	@FXML
	private TextField lblOptionD;

	@FXML
	private RadioButton radioButtonD;

	@FXML
	private TextField lblOptionC;

	@FXML
	private RadioButton radioButtonC;

	@FXML
	private RadioButton radioButtonB;

	private int n;
	private ArrayList<String> righe;
	ToggleGroup group = new ToggleGroup();
	private Domanda domanda;
	private  ArrayList<Domanda> righeFile;
	private String nuovaDomanda;
	private String nomeFile;
	private String domandaPassata;
	private int index;
	
	/**
	 * 
	 *EDITOR IN CUI CREO NUOVE DOMANDE O MODIFICO DOMANDE GI� ESISTENTI
	 * 
	 */
	
	//valori passati da GestioneDomandeController:
	public void controlloAzione(int n, int index, ArrayList<String> righe, ArrayList<Domanda> righeFile,String nomeFile, String domandaPassata) {
		this.n = n;
		this.righe= righe;
		this.righeFile = righeFile;
		this.nomeFile = nomeFile;
		this.domanda = new Domanda();
		this.index = index;

		//Imposto un valore per domandaPassata solo se in GestioneDomandeController ho selezionato "Modifica domanda":
		if(domandaPassata!=null) {
			this.domandaPassata = domandaPassata;
		}

		//Se n==1, mostro nei label la domanda selezionata dalla ListView della finestra precedente:
		if(n==1) {
			String split[] = domandaPassata.split(",");
			Domanda domanda = new Domanda(split[0],split[1],split[2]);
			//testo domanda:
			lblQuestion.setText(domanda.getTesto());
			lblOptionA.setText(domanda.getA());
			lblOptionB.setText(domanda.getB());
			lblOptionC.setText(domanda.getC());
			lblOptionD.setText(domanda.getD());
		}

		radioButtonA.setToggleGroup(group);
		radioButtonB.setToggleGroup(group);
		radioButtonC.setToggleGroup(group);
		radioButtonD.setToggleGroup(group);
	}

	//Riempimento dei label:
	public void setFinestra() {
		//testo domanda:
		domanda.setTesto(lblQuestion.getText());
		//opzioni:
		domanda.setA(lblOptionA.getText());
		domanda.setB(lblOptionB.getText());
		domanda.setC(lblOptionC.getText());
		domanda.setD(lblOptionD.getText());

		//risposta esatta:
		if(radioButtonA.isSelected()) {
			domanda.setRispostaEsatta(lblOptionA.getText());
		}else if(radioButtonB.isSelected()) {
			domanda.setRispostaEsatta(lblOptionB.getText());
		}else if(radioButtonC.isSelected()) {
			domanda.setRispostaEsatta(lblOptionC.getText());
		}else if(radioButtonD.isSelected()) {
			domanda.setRispostaEsatta(lblOptionD.getText());
		}
		
		//rimozione caratteri illeciti utilizzati nei file come divisori ("," e "/"):
		domanda.rimuoviCaratteri();
	}
	
	@FXML
	private	void indietro(ActionEvent event) throws IOException {
		//Impedisco di tornare indietro se non � stato eseguito ci� che � richiesto nell'editor:
		//Se non ho inserito  testo della domanda/opzioni:
		if(lblQuestion.getText().equals("Inserire testo domanda")||lblOptionA.getText().equalsIgnoreCase("Inserire opzione A")||lblOptionB.getText().equalsIgnoreCase("Inserire opzione B")||lblOptionC.getText().equalsIgnoreCase("Inserire opzione C")||lblOptionD.getText().equalsIgnoreCase("Inserire opzione D")){
			Alert alert = new Alert(AlertType.ERROR);
			alert.setTitle("Error");
			alert.setHeaderText(null);
			alert.setContentText("Riempire tutti i campi");
			alert.showAndWait();
		}
		//Se non ho selezionato la risposta esatta:
		else if(!radioButtonA.isSelected() && !radioButtonB.isSelected() &&!radioButtonC.isSelected() && !radioButtonD.isSelected() ) {
			Alert alert2 = new Alert(AlertType.ERROR);
			alert2.setTitle("Error");
			alert2.setHeaderText(null);
			alert2.setContentText("Selezionare una risposta");
			alert2.showAndWait();
		}  
		else{
			//CREAZIONE NUOVA DOMANDA:
			if(n==0) {
				try {
					setFinestra();
					
					//Modifico ListView:
					righeFile.add(domanda);

					//Aggiungo domanda nell'ArrayList che gestisce le righe del file:
					String nuovaDomanda = righeFile.get(righeFile.size()-1).nuovaDomanda();
					righe.add( nuovaDomanda);		
					
					//Riscrivo file:
					scritturaFile();

					FXMLLoader loader = new FXMLLoader(getClass().getResource("/javafxproject/fxml/GestioneDomande.fxml"));
					Parent root =(Parent) loader.load();
					GestioneDomandeController gestione = loader.getController();
					gestione.file(righeFile,righe, nomeFile);

					Stage stage=(Stage)((Node)event.getSource()).getScene().getWindow();
					stage.setScene(new Scene(root));
					stage.show();
				} catch (IOException e) {
					e.printStackTrace();
				}

				//MODIFICA DI UNA DOMANDA GI� ESISTENTE:
			}else if(n==1) {
				try {
					setFinestra();

					//Modifico listview:
					righeFile.remove(index);//Rimuovo la domanda selezionata dalla listView(Non ancora modificata);
					righeFile.add(index,domanda);//Aggiungo nella ListView la domanda modificata nella stessa posizione

					//Aggiungo domanda nell'ArrayList che gestisce le righe del file
					String nuovaDomanda = righeFile.get(index).nuovaDomanda();
					righe.remove(index);
					righe.add(index, nuovaDomanda);		
					
					//Riscrivo file:
					scritturaFile();

					FXMLLoader loader = new FXMLLoader(getClass().getResource("/javafxproject/fxml/GestioneDomande.fxml"));
					Parent root =(Parent) loader.load();
					GestioneDomandeController gestione = loader.getController();
					gestione.file(righeFile,righe, nomeFile);

					Stage stage=(Stage)((Node)event.getSource()).getScene().getWindow();
					stage.setScene(new Scene(root));
					stage.show();
				} catch (IOException e) {
					e.printStackTrace();
				}

			}
		}
	}
	
	public void scritturaFile() {
		//Riscrivo il  file:
		PrintWriter outStream = null;
		try {
			outStream = new PrintWriter( new FileOutputStream(nomeFile,false));
		}catch(FileNotFoundException e) {

		}
		for(int i = 0; i<righe.size(); i++){
			if(i<righe.size()-1) {
				outStream.println(righe.get(i));

			}else {
				outStream.print(righe.get(i));
			}
		}
		outStream.close();	
	}

	@FXML
	private void annulla(ActionEvent event) {
		try {
			//Avviso che le modifiche apportate al file sono state annullate:
			Alert alert = new Alert(AlertType.ERROR);
			alert.setTitle("Attenzione");
			alert.setHeaderText(null);
			alert.setContentText("Modifiche apportate al file annullate");
			alert.showAndWait();

			FXMLLoader loader = new FXMLLoader(getClass().getResource("/javafxproject/fxml/GestioneDomande.fxml"));
			Parent root =(Parent) loader.load();
			GestioneDomandeController gestione = loader.getController();
			gestione.file(righeFile,righe, nomeFile);

			Stage stage=(Stage)((Node)event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}