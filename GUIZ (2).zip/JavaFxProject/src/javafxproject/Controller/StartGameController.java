package javafxproject.Controller;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.time.Duration;
import java.util.ArrayList;
import java.util.EventObject;
import java.util.Random;
import java.util.ResourceBundle;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicIntegerArray;

import com.sun.glass.events.MouseEvent;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.stage.Stage;
import javafxproject.Domanda;

/**
 * FXML Controller class
 *
 * @author belbeni
 */
public class StartGameController implements Initializable {
	@FXML
	private Button next;
	@FXML
	private Label lblPlayerName1;
	@FXML
	private Label lblPlayerName3;
	@FXML
	private Label lblPlayerName2;
	@FXML
	private Label lblPlayerScore1;
	@FXML
	private Label lblPlayerScore3;
	@FXML
	private Label lblPlayerScore2;
	@FXML
	private Label lblRound;
	@FXML
	private RadioButton radioButtonC;
	@FXML
	private RadioButton radioButtonD;
	@FXML
	private RadioButton radioButtonA;
	@FXML
	private RadioButton radioButtonB;
	@FXML
	private Label lblQuestion;
	@FXML
	private Label timer;

	private final Integer startTime = 20;
	private Integer secondi = startTime;
	private ArrayList<Domanda> infoGioco;
	private Domanda domandaEstratta;
	private ArrayList<String> righeFile;
	private AtomicInteger giocatori;
	private int numeroDomande;
	private AtomicInteger turno = new AtomicInteger(1);
	private AtomicInteger giocatore_attuale = new AtomicInteger(1);
	private AtomicIntegerArray arrayPunteggio;
	private Timeline time = new Timeline();
	private AtomicInteger punteggio;
	private String nomi;
	private int n; //variabile che serve per controllare quale round eseguire

	//VALORI PASSATI DALLA FINESTRA INIZIAPARTITACONTROLLER:
	public void finestra(ArrayList<Domanda>infoGioco, Domanda domandaEstratta,ArrayList<String> righeFile,AtomicInteger giocatori, int numeroDomande,String nomi,int n,AtomicIntegerArray arrayPunteggio) {
		this.infoGioco = infoGioco;
		this.domandaEstratta= domandaEstratta;
		this.righeFile = righeFile;
		this.domandaEstratta = domandaEstratta;
		this.giocatori = giocatori;
		this.nomi = nomi;

		this.n = n;
		this.arrayPunteggio = arrayPunteggio;

		//controllo se devo eseguire le domande perditutto e  imposto il numero di domande a 1
		if(n == 2) {
			this.numeroDomande = 1;
		}else {
			this.numeroDomande = numeroDomande;
		}
		if(n == 1) {
			KeyFrame frame = new KeyFrame(javafx.util.Duration.seconds(1), new EventHandler<ActionEvent>() {

				@Override
				public void handle(ActionEvent event) {
					secondi--;
					timer.setText(secondi.toString());
					if(secondi==0 ){
						time.stop();

						try {
							controlloTurno(  numeroDomande, turno,  punteggio, giocatore_attuale, giocatori, domandaEstratta, risposta, arrayPunteggio, event);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						if(estraiDomanda(infoGioco, domandaEstratta)){

							setFinestra(domandaEstratta,turno, giocatore_attuale,arrayPunteggio,nomi);    
						}
					}
				}
			});

			time.getKeyFrames().add(frame);
		}

		setFinestra( domandaEstratta, turno,  giocatore_attuale, arrayPunteggio, nomi);
	}
	
	
	
	//Pagina di gioco:
	public void setFinestra(Domanda domandaEstratta,AtomicInteger turno, AtomicInteger giocatore_attuale,AtomicIntegerArray arrayPunteggio, String nomi)
	{
		String turnoGiocatore = "Turno " + turno + " giocatore " + giocatore_attuale;
		lblRound.setText(turnoGiocatore);

		//punti
		int p = arrayPunteggio.get(giocatore_attuale.get()-1);
		String punti = String.valueOf(p);

		//giocatori
		if(giocatore_attuale.get() ==1){
			lblPlayerScore1.setText(punti);

			if(arrayPunteggio.length()==2) {
				lblPlayerScore2.setText(String.valueOf(arrayPunteggio.get(1)));

			}else if(arrayPunteggio.length()==3) {
				lblPlayerScore3.setText(String.valueOf(arrayPunteggio.get(2)));
				lblPlayerScore2.setText(String.valueOf(arrayPunteggio.get(1)));
			}
		}else if(giocatore_attuale.get()==2) {
			lblPlayerScore2.setText(punti);
			lblPlayerScore1.setText(String.valueOf(arrayPunteggio.get(0)));
		}else if(giocatore_attuale.get()==3) {
			lblPlayerScore3.setText(punti);
			lblPlayerScore2.setText(String.valueOf(arrayPunteggio.get(1)));
		}

		if(n ==1) {
			doTime();
		}
		//nomi giocatori:
		String[] split = nomi.split("/");
		lblPlayerName1.setText(split[0]);

		if(split.length==2){
			lblPlayerName2.setText(split[1]);
		}else if(split.length==3) {
			lblPlayerName2.setText(split[1]);
			lblPlayerName3.setText(split[2]);
		}

		//testo domanda:
		lblQuestion.setText(domandaEstratta.getTesto());

		//opzioni
		String[] possibiliRisposte = domandaEstratta.getPossibiliRisposte().split("/");
		radioButtonA.setText(possibiliRisposte[0]);
		radioButtonB.setText(possibiliRisposte[1]);
		radioButtonC.setText(possibiliRisposte[2]);
		radioButtonD.setText(possibiliRisposte[3]);  

		//bottoni
		ToggleGroup group = new ToggleGroup();
		radioButtonA.setToggleGroup(group);
		radioButtonB.setToggleGroup(group);
		radioButtonC.setToggleGroup(group);
		radioButtonD.setToggleGroup(group);

		//resetto i bottoni dalla selezione precedente:
		radioButtonA.setSelected(false);
		radioButtonB.setSelected(false);
		radioButtonC.setSelected(false);
		radioButtonD.setSelected(false);
	}

	//CONTROLLO RISPOSTA ESATTA E INCREMENTO PUNTEGGIO
	public boolean risposta(Domanda domandaEstratta,String risposta,AtomicInteger punteggio,AtomicInteger giocatore_attuale, AtomicIntegerArray arrayPunteggio){
		boolean controllo = false;
		String esatta = domandaEstratta.getRispostaEsatta();
		if(risposta.equals(esatta)){
			controllo = true;
			return controllo;
		}
		return controllo;
	}

	//gestione turni
	public void controlloTurno(int numeroDomande,AtomicInteger turno, AtomicInteger punteggio,AtomicInteger giocatore_attuale,AtomicInteger giocatore,Domanda domandaEstratta,String risposta,AtomicIntegerArray arrayPunteggio, ActionEvent event) throws IOException{
		boolean controllo = risposta( domandaEstratta, risposta, punteggio, giocatore_attuale, arrayPunteggio);
		//incremento punteggio per i primi due turni:
		if(n!=2) {
			if((turno.get()<numeroDomande)||(turno.get()==numeroDomande && giocatore_attuale.get()<giocatori.get())){ 
				if ( controllo) {
					arrayPunteggio.getAndIncrement(giocatore_attuale.get()-1);
					System.out.println(turno + " " + giocatore_attuale.get());
				}

				if(giocatore_attuale.get()%giocatore.get()==0){
					turno.getAndIncrement(); 
					giocatore_attuale.set(1); 
					System.out.println(turno + " " + giocatore_attuale.get());

				}else{
					giocatore_attuale.getAndIncrement();  
					System.out.println(turno + " " + giocatore_attuale.get());
				}
			}else{
				if ( controllo) {
					arrayPunteggio.getAndIncrement(giocatore_attuale.get()-1);
				}

				try {
					FXMLLoader loader = new FXMLLoader(getClass().getResource("/javafxproject/fxml/Round.fxml"));
					Parent root =(Parent) loader.load();
					System.out.println(nomi);

					RoundController round = loader.getController();
					round.finestra(infoGioco,  domandaEstratta, righeFile, giocatori,  numeroDomande, nomi, arrayPunteggio,n);

					Stage stage=(Stage)((Node)event.getSource()).getScene().getWindow();
					stage.setScene(new Scene(root));
					stage.show();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}		

		}//incremento per turno perditutto:
		else if(n==2){
			if((turno.get()<numeroDomande)||(turno.get()==numeroDomande && giocatore_attuale.get()<giocatori.get())){ 

				if ( controllo) {
					int punteggioFinale =arrayPunteggio.getAndIncrement(giocatore_attuale.get()-1)*5;
					arrayPunteggio.set(giocatore_attuale.get()-1,punteggioFinale);
					System.out.println(turno + " " + giocatore_attuale.get());
				}else {
					arrayPunteggio.set(giocatore_attuale.get()-1,0);

				}

				if(giocatore_attuale.get()%giocatore.get()==0){
					turno.getAndIncrement(); 
					giocatore_attuale.set(1); 
					System.out.println(turno + " " + giocatore_attuale.get());

				}else{
					giocatore_attuale.getAndIncrement();  
					System.out.println(turno + " " + giocatore_attuale.get());
				}
			}else{
				if ( controllo) {
					int punteggioFinale =arrayPunteggio.getAndIncrement(giocatore_attuale.get()-1)*5;
					arrayPunteggio.set(giocatore_attuale.get()-1,punteggioFinale);
				}else {
					arrayPunteggio.set(giocatore_attuale.get()-1,0);

				}
				try {
					FXMLLoader loader = new FXMLLoader(getClass().getResource("/javafxproject/fxml/FinalScore.fxml"));
					Parent root =(Parent) loader.load();

					FinalScoreController score = loader.getController();
					score.finestra( arrayPunteggio,nomi);

					Stage stage=(Stage)((Node)event.getSource()).getScene().getWindow();
					stage.setScene(new Scene(root));
					stage.show();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	//Estrazioni domande
	public Boolean estraiDomanda(ArrayList<Domanda> infoGioco,Domanda domandaEstratta)
	{
		//estrazione domanda casuale:
		Random r = new Random();
		int num = 0;
		int nDomande = infoGioco.size();
		System.out.println(nDomande);
		if(nDomande > 0)
		{
			num = r.nextInt(nDomande);

			domandaEstratta.setTesto(infoGioco.get(num).getTesto());
			domandaEstratta.setPossibiliRisposte(infoGioco.get(num).getPossibiliRisposte());
			domandaEstratta.setRispostaEsatta(infoGioco.get(num).getRispostaEsatta());

			//rimozione della domanda estratta dall'elenco
			infoGioco.remove(num);
			return true;
		}
		else
		{
			//Ritorna FALSE perch� non ha trovato domande disponibili
			return false;
		}
	}

	@FXML
	//Salvo la risposta selezionata:
	String risposta = "";
	public void next(ActionEvent event) throws Exception {
		//Salvo la risposta selezionata:
		//String risposta = "";
		if(!radioButtonA.isSelected() && !radioButtonB.isSelected() &&!radioButtonC.isSelected() && !radioButtonD.isSelected() ) {

			Alert alert = new Alert(AlertType.ERROR);
			alert.setTitle("Error");
			alert.setHeaderText(null);
			alert.setContentText("Selezionare una risposta");
			alert.showAndWait();

		}else {

			if(radioButtonA.isSelected()){
				risposta = radioButtonA.getText();

			}else if(radioButtonB.isSelected()){
				risposta = radioButtonB.getText();
			}else if(radioButtonC.isSelected()){
				risposta = radioButtonC.getText();
			}else if(radioButtonD.isSelected()){
				risposta = radioButtonD.getText();
			}

			//risposta( domandaEstratta, risposta,punteggio,giocatore_attuale,arrayPunteggio);
			controlloTurno(  numeroDomande, turno,  punteggio, giocatore_attuale, giocatori, domandaEstratta, risposta, arrayPunteggio, event);
			if(estraiDomanda(infoGioco, domandaEstratta)){

				setFinestra(domandaEstratta,turno, giocatore_attuale,arrayPunteggio,nomi);    
			}
			else
			{
				//finestra alert che avverte che le domande sono esaurite
				Alert alert = new Alert(AlertType.ERROR);
				alert.setTitle("Errore");
				alert.setHeaderText("Domande Esaurite");
				alert.setContentText("Non ci sono pi� domande da estrarre.");

				alert.showAndWait();
			}
		}
	}

	@FXML
	private void closeGame(ActionEvent event) throws IOException{
		String selection = null;
		Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Delete" +selection+ "?",ButtonType.OK,ButtonType.CANCEL);
		alert.setTitle("Warning");
		alert.setHeaderText(null);
		alert.setContentText("Sei sicuro di voler abbandonare la partita?");
		alert.showAndWait();
		if(alert.getResult() == ButtonType.OK){
			System.exit(0);
		}else{
		}
	}

	//metodo che crea il timer nelle domande a tempo:
	//metodo che crea il timer nelle domande a tempo:
	private void doTime() {
		secondi = startTime;

		
		time.setCycleCount(Timeline.INDEFINITE);
		if(time!=null) {
			time.stop();
		}

		time.playFromStart();

	}




	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub

	}
}
