package javafxproject.Controller;
import java.io.File;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.concurrent.atomic.AtomicInteger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import javafxproject.Domanda;

/**
 *
 * @author belbeni
 */
public class NuovaPartitaController implements Initializable{

	@FXML
	private ChoiceBox<String> difficultyBox;
	@FXML
	private ChoiceBox<Integer> numberPlayerBox;
	@FXML
	private ChoiceBox<Integer>numberQuestionBox;
	@FXML
	private Label lblWarning;

	//List per salvare diverse difficolt� 
	ObservableList difficultyList = FXCollections.observableArrayList();

	//List per salvare il numero di giocatori
	ObservableList numberPlayerList = FXCollections.observableArrayList();
	
	//List per salvare il numero di domande per ogni giocatore
	ObservableList numberQuestionList = FXCollections.observableArrayList();
	ArrayList<String> impostazioni = new ArrayList<String>();
	String diffDefault;

	@Override
	public void initialize(URL location, ResourceBundle resources) {

		loadDataNumberPlayer();
		loadDataNumberQuestion();
		try {
			leggiImpostazioni(impostazioni);
			
			//Se disattivo la possibilit� di scegliere la difficolt� in ConfigurazioniController:
			if (impostazioni.get(0).equalsIgnoreCase("no")) { 
				difficultyBox.setDisable(true);
				
			}
			else {
				difficultyBox.setDisable(false);
			}
			diffDefault = impostazioni.get(1);
		} catch (IOException e) {
			e.printStackTrace();
			difficultyBox.setDisable(false);
		}
		loadDataDifficulty();
	}
	
	//lettura impostazioni
		private void leggiImpostazioni(ArrayList<String> righe) throws IOException {
			//Se la difficolt�  � mista, carico nell'arrayList righeFile tutti i file di testo:

			BufferedReader lettore = null;

			try
			{
				lettore = new BufferedReader(new FileReader("src/javafxproject/txt/options.txt"));
			}
			catch(FileNotFoundException e)
			{
				System.exit(0);
			}
			String r =null;
			try 
			{
				r = lettore.readLine();
			} 
			catch (IOException e) 
			{
				System.exit(0);
			}

			while(r!=null)
			{
				righe.add(r);
				try 
				{
					r = lettore.readLine();

				}
				catch (IOException e)
				{
					System.exit(0);
				}
			}		

			lettore.close();
		}

	@FXML
	private void loadDataDifficulty(){
		difficultyList.removeAll(difficultyList);
		String a = "Facile";
		String b = "Media";
		String c = "Difficile";
		String d = "Mista";
		difficultyList.addAll(a,b,c,d);
		difficultyBox.getItems().addAll(difficultyList);
		
		if (diffDefault.equalsIgnoreCase(a)){
			difficultyBox.getSelectionModel().select(0);
		}
		else if (diffDefault.equalsIgnoreCase(b)){
			difficultyBox.getSelectionModel().select(1);
		}
		else if (diffDefault.equalsIgnoreCase(c)){
			difficultyBox.getSelectionModel().select(2);
		}
		else if (diffDefault.equalsIgnoreCase(d)){
			difficultyBox.getSelectionModel().select(3);
		}
	}   
	
	//Se disattivo la possibilit� di scegliere il livello nel pannello di controllo:
	@FXML
	public void loadDataDifficultySetDisable(String nomeFile){
		difficultyBox.setValue(nomeFile);
		difficultyBox.setDisable(true);

	}   
	@FXML
	private void loadDataNumberPlayer(){
		int a = 1;
		int b = 2;
		int c = 3;

		numberPlayerList.addAll(a,b,c);
		numberPlayerBox.getItems().addAll(numberPlayerList);
	}  
	
	@FXML
	private void loadDataNumberQuestion(){
		int a = 3;
		int b = 5;
		int c = 10;

		numberQuestionList.addAll(a,b,c);
		numberQuestionBox.getItems().addAll(numberQuestionList);
	}  

	//Questo metodo inizia la parita di gioco
	AtomicInteger giocatore = new AtomicInteger(0);
	String nomeFile = "";
	int numeroDomande = 0;
	@FXML
	private void IniziaPartita(ActionEvent event) throws Exception{
		if(difficultyBox.getValue() == null || numberPlayerBox.getValue() == null){
			Alert alert = new Alert(AlertType.ERROR);
			alert.setTitle("Error");
			alert.setHeaderText(null);
			alert.setContentText("Compilare tutti i campi per proseguire");
			alert.showAndWait();

		}
		else{
			//Salvataggio numero giocatori e difficolt� di gioco selezionati
			giocatore.set(numberPlayerBox.getValue());
			if(difficultyBox.getValue().equals("Mista")) {
				nomeFile = difficultyBox.getValue();
			}else {
			nomeFile ="src/javafxproject/txt/" + difficultyBox.getValue() + ".txt";
			}
			
			numeroDomande = numberQuestionBox.getValue();		
	
			try {
				FXMLLoader loader = new FXMLLoader(getClass().getResource("/javafxproject/fxml/NamePlayer.fxml"));

				Parent root =(Parent) loader.load();

				//passaggio delle variabili utili per la finestra di gioco da NuovaPartitaController a StartgameController:
			
				NamePlayerController startGame = loader.getController();

				startGame.informazioniPartita(giocatore,nomeFile,numeroDomande,difficultyBox);
				
				Stage stage=(Stage)((Node)event.getSource()).getScene().getWindow();
				stage.setScene(new Scene(root));
				stage.show();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	@FXML
	private void TornaPrincipalMenu(ActionEvent event) throws Exception{
		Parent root = FXMLLoader.load(getClass().getResource("/javafxproject/fxml/PrincipalMenu.fxml"));
		Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
		Scene scene = new Scene(root,600,650);
		window.setScene(scene);
		window.show();

	}

	@FXML
	private void closeApp(ActionEvent event){
		System.exit(0);
	}
}
