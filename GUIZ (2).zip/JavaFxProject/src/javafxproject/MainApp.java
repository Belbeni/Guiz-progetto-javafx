
package javafxproject;

import javafxproject.MainApp;
import java.io.IOException;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import static javafxproject.MainApp.main;

/**
 *
 * @author belbeni
 */
public class MainApp extends Application{
    
   
    private double xOffset = 0;
    private double yOffset = 0;
    Stage stage;
    AnchorPane layout;
    
    @Override
    public void start(Stage stage) throws Exception {
        
        Parent root = FXMLLoader.load(getClass().getResource("/javafxproject/fxml/PrincipalMenu.fxml"));
        
         root.setOnMousePressed((MouseEvent event) -> {
            xOffset = event.getSceneX();
            yOffset = event.getSceneY();
        });
          
        root.setOnMouseDragged((MouseEvent event) -> {
            stage.setX(event.getSceneX() - xOffset);
            stage.setY(event.getScreenY() - yOffset);
            stage.setOpacity(0.7f);
        });
        
        root.setOnDragDone((e) -> {
            stage.setOpacity(1.0f);
    
        });
        
        root.setOnMouseReleased((e) -> {
            stage.setOpacity(1.0f);
    
        });
        
        Scene scene = new Scene(root,600,700);
        stage.setResizable(false);
        stage.setScene(scene);
        stage.show();
    }
 
  
    
    public static void main(String[] args){
        launch(args);
    }
}
