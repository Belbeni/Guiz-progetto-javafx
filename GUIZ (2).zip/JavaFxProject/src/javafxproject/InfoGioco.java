package javafxproject;

import java.util.concurrent.atomic.AtomicInteger;
import javafx.collections.ObservableList;
import javafx.scene.control.ChoiceBox;

public class InfoGioco {
	private AtomicInteger giocatori;
	private String difficolt�;
	
	//costruttore
	public InfoGioco(AtomicInteger giocatori, String difficolt�) {
		this.giocatori = giocatori;
		this.difficolt� = difficolt�;
	}
	
	//get/set
	//Imposto e ottengo il valore del numero giocatori selezionato:
	public void setGiocatori(ChoiceBox numberPlayerBox) {
		int value = (int) numberPlayerBox.getValue();
		giocatori.set(value);
	}
	public AtomicInteger getGiocatori() {
		return giocatori;
		}
	
	//Imposto e ottengo il valore della difficolt� selezionata:
	public void setDifficolt�(ChoiceBox difficultyBox) {
		difficolt� = (String) difficultyBox.getValue();
	}
	public String getDifficolt�() {
		return difficolt�;
	}
	
}
