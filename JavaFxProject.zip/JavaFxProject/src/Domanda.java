package javafxproject;

//CLASSE CHE MI PERMETTE LA GESTIONE DELLE RIGHE DEI FILE
public class Domanda {
	private String testo;
	private String a;
	private String b;
	private String c;
	private String d;
	private String rispostaEsatta;

	public Domanda(String testo,String risposte, String rispostaEsatta){
		this.testo = testo;
		this.rispostaEsatta = rispostaEsatta;

		//split per ottenere le varie opzioni
		String[] possibiliRisposte = risposte.split("/");
		a = possibiliRisposte[0];
		b = possibiliRisposte[1];
		c = possibiliRisposte[2];
		d = possibiliRisposte[3];        
	}

	public Domanda(){
		this.testo = "";
		this.a = "";
		this.b = "";
		this.c = "";
		this.d = "";
	}

	public String getTesto(){
		return testo;
	}

	public void setTesto(String inTesto) {
		this.testo = inTesto;
	}

	public void setRispostaEsatta(String inRispostaEsatta) {
		this.rispostaEsatta = inRispostaEsatta;
	}

	public void setA(String inA){
		this.a = inA;
	}

	public void setB(String inB){
		this.b = inB;
	}

	public void setC(String inC){
		this.c = inC;
	}
	public void setD(String inD){
		this.d = inD;
	}

	public String getA(){
		return a;
	}
	public String getB(){
		return b;
	}
	public String getC(){
		return c;
	}
	public String getD(){
		return d;
	}
	public void setPossibiliRisposte(String inPossibiliRisposte) {
		String[] possibiliRisposte = inPossibiliRisposte.split("/");
		a = possibiliRisposte[0];
		b = possibiliRisposte[1];
		c = possibiliRisposte[2];
		d = possibiliRisposte[3]; 
	}

	public String getPossibiliRisposte(){
		return a+ "/"+ b + "/" + c + "/" + d;
	}


	public String getRisposte(){
		return a + "\n" + b + "\n" + c + "\n" + d;
	}

	public String getRispostaEsatta(){
		return rispostaEsatta;
	}

	public String toString(){
		return testo + "\n" + a + "\n" + b + "\n" + c + "\n" + d + "\n"; 
	}


	/* 1)Metodo che permette di inserire una nuova domanda nel formato corretto 
    del  filetxt:*/
	public String nuovaDomanda(){
		return getTesto() + ","+ getPossibiliRisposte() + "," + getRispostaEsatta();
	}


	/* 2)Metodo che mi permette di rimuovere dal testo delle domande i caratteri
    "," e "/" (per evitare problemi col formato del testo):*/
	public void rimuoviCaratteri(){
		String domanda = getTesto();
		//Faccio corrispondere ogni carattere del testo della domanda a un
		//diverso indice dell' array:
		String[] splitDomanda = domanda.split("");

		//controllo carattere per carattere:
		for(int i = 0; i<splitDomanda.length; i++){
			if(splitDomanda[i].equals(",")){
				splitDomanda[i] = " "; //sostituisco la virgola con uno spazio vuoto
			}else if(splitDomanda[i].equals("/")){
				splitDomanda[i] = "-"; //sostituisco lo slash con un trattino
			}                    
		}

		//sostituzione del testo della domanda inserito con il testo della
		//domanda modificato:
		String nuovoTesto = "";
		for(int j = 0; j<splitDomanda.length; j++){
			nuovoTesto += splitDomanda[j];
		}
		setTesto(nuovoTesto);

		//CONTROLLO CARATTERI CORRETTI IN RISPOSTA

		String risposte = getRisposte();
		String[] split = risposte.split("\n");
		String[] splitRisposte = new String[4];

		for(int y = 0;y<splitRisposte.length;y++){
			splitRisposte[y] = "";
		}


		for(int q = 0; q<split.length; q++){
			String[] splitArray = split[q].split("");
			for(int w = 0; w<splitArray.length; w++){
				if(splitArray[w].equals(",")){
					splitArray[w] = " ";
					splitRisposte[q] += splitArray[w];    				

				}else if(splitArray[w].equals("/")){
					splitArray[w]= "-";
					splitRisposte[q] += splitArray[w];

				}else{
					splitRisposte[q] += splitArray[w];
				}

			}
		}

		setA(splitRisposte[0]);
		setB(splitRisposte[1]);
		setC(splitRisposte[2]);
		setD(splitRisposte[3]);

		String nuoveRisposte = getPossibiliRisposte();

		setPossibiliRisposte(nuoveRisposte);

	}
}