package javafxproject.Controller;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.stage.Stage;
import javafxproject.Domanda;

/**
 *
 * @author belbeni
 */
public class ConfigurazioniController implements Initializable{

	@FXML
	private RadioButton radioButtonSi;

	@FXML
	private RadioButton radioButtonNo;

	@FXML
	private ChoiceBox<?> DifficultyDefault;

	@FXML
	private Button Facile;

	@FXML
	private Button Media;

	@FXML
	private Button Difficile;
	ToggleGroup group = new ToggleGroup();
	private String diffDefault;

	private ObservableList difficultyList = FXCollections.observableArrayList();//List per salvare diverse difficoltà 
	ArrayList<Domanda>righe  = new ArrayList<Domanda>(); 
	ArrayList<String> righeFile = new ArrayList<String>();

	/**
	 * 
	 * PANNELLO CONFIGURAZIONI
	 * 
	 */

	@FXML
	private void loadDataDifficulty(){
		difficultyList.removeAll(difficultyList);
		String a = "Facile";
		String b = "Media";
		String c = "Difficile";
		String d = "Mista";
		difficultyList.addAll(a,b,c,d);
		DifficultyDefault.getItems().addAll(difficultyList);
		DifficultyDefault.getSelectionModel().select(0);
		DifficultyDefault.setDisable(true);

		//DifficultyBox inizialmente disattivata.
		//Attivazione DifficultyBox cliccando radioButtonNo:
		radioButtonNo.setOnMouseClicked(mouseEvent -> {
			boolean disable = !DifficultyDefault.isDisabled();
			DifficultyDefault.setDisable(false);
		});

		//Disattivo DifficultyBox cliccando radioButtonNo
		radioButtonSi.setOnMouseClicked(mouseEvent -> {
			boolean disable = !DifficultyDefault.isDisabled();
			DifficultyDefault.setDisable(true);
		});
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		loadDataDifficulty();
		radioButtonSi.setToggleGroup(group);
		radioButtonNo.setToggleGroup(group);
	}

	String nome = "";
	@FXML
	private void ModificaFacile(ActionEvent event) throws IOException {
		nome = "src/javafxproject/txt/Facile.txt";
		letturaFile(nome,righeFile);

		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/javafxproject/fxml/GestioneDomande.fxml"));

			Parent root =(Parent) loader.load();
			GestioneDomandeController domande = loader.getController();

			domande.file(righe,righeFile,nome);

			Stage stage=(Stage)((Node)event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@FXML
	private void ModificaMedia(ActionEvent event) throws IOException {
		nome = "src/javafxproject/txt/Media.txt";
		letturaFile(nome,righeFile);

		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/javafxproject/fxml/GestioneDomande.fxml"));

			Parent root =(Parent) loader.load();
			GestioneDomandeController domande = loader.getController();

			domande.file(righe,righeFile,nome);

			Stage stage=(Stage)((Node)event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@FXML
	private void ModificaDifficile(ActionEvent event) throws IOException {
		nome = "src/javafxproject/txt/Difficile.txt";
		letturaFile(nome,righeFile);

		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/javafxproject/fxml/GestioneDomande.fxml"));

			Parent root =(Parent) loader.load();
			GestioneDomandeController domande = loader.getController();

			domande.file(righe,righeFile,nome);

			Stage stage=(Stage)((Node)event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	//String open = "";
	@FXML
	private void TornaPrincipalMenu(ActionEvent event) throws Exception{
		//salvo le impostazioni relative alla difficolt� nel file "options.txt".
		
		//Creazione file:
		PrintWriter file = null;
		try {
			file = new PrintWriter( new FileOutputStream("src/javafxproject/txt/options.txt",false));
		}catch(FileNotFoundException e) {

		}

		//salvo comandi per impostare il choiceBox in NuovaPartitaController
		if (radioButtonSi.isSelected()) {
			file.println("yes");// attiva la choiceBox relativa in NuovaPartitaController
		}
		else if (radioButtonNo.isSelected()) {
			file.println("no");// disattiva la choiceBox relativa in NuovaPartitaController

		}
		file.println((String)DifficultyDefault.getValue());
		file.close();

		Parent root = FXMLLoader.load(getClass().getResource("/javafxproject/fxml/PrincipalMenu.fxml"));
		Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
		Scene scene = new Scene(root,600,650);
		window.setScene(scene);
		window.show();
	}
	@FXML
	private void closeApp(ActionEvent event){
		System.exit(0);
	}

	//lettura file che andr� a modificare nell'Editor di testo:
	private void letturaFile(String nome,ArrayList<String> righeFile) throws IOException {
		BufferedReader lettore = null;

		try
		{
			lettore = new BufferedReader(new FileReader(nome));
		}
		catch(FileNotFoundException e)
		{
			System.exit(0);
		}
		String r =null;
		try 
		{
			r = lettore.readLine();
		} 
		catch (IOException e) 
		{
			System.exit(0);
		}

		while(r!=null)
		{
			righeFile.add(r);
			try 
			{
				r = lettore.readLine();

			}
			catch (IOException e)
			{
				System.exit(0);
			}
		}

		Domanda d;
		for(int i = 0;i<righeFile.size(); i++)
		{ 
			String[] opzioni = righeFile.get(i).split(",");
			d = new Domanda(opzioni[0], opzioni[1],opzioni[2]);    
			righe.add(d);
		} 		

		lettore.close();
	}
}