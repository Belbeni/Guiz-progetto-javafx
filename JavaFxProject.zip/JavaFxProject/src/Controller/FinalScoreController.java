package javafxproject.Controller;

import java.io.IOException;
import java.util.concurrent.atomic.AtomicIntegerArray;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class FinalScoreController {

	@FXML
	private Label lbl1;
	@FXML
	private Label lbl2;

	@FXML
	private Label lbl3;
	@FXML
	private Label lblWinner;

	private String nomi;
	private AtomicIntegerArray arrayPunteggio;


	/**
	 * 
	 *PUNTEGGIO FINALE DEL GIOCO
	 * 
	 */

	public void finestra(AtomicIntegerArray arrayPunteggio, String nomi) {
		this.nomi = nomi;
		this.arrayPunteggio = arrayPunteggio;

		String[] split = nomi.split("/");
		String vincitore = "";
		String[] split2 = lblWinner.getText().split(" ");

		if(split.length == 1) {
			lbl2.setText(split[0] + " " + String.valueOf(arrayPunteggio.get(0)));
			lblWinner.setVisible(false);

		}else if(split.length==2){
			lbl1.setText(split[0] + " " + String.valueOf(arrayPunteggio.get(0)));
			lbl2.setText(split[1] + " " + String.valueOf(arrayPunteggio.get(1)));

			if(arrayPunteggio.get(0)>arrayPunteggio.get(1)) {
				split2[1] = split[0];
			}else {
				split2[1] = split[1];
			}			

		}else if(split.length==3) {
			lbl1.setText(split[0] + " " + String.valueOf(arrayPunteggio.get(0)));
			lbl2.setText(split[1] + " " + String.valueOf(arrayPunteggio.get(1)));
			lbl3.setText(split[2] + " " + String.valueOf(arrayPunteggio.get(2)));

			if(arrayPunteggio.get(0)>arrayPunteggio.get(1)&&arrayPunteggio.get(0)>arrayPunteggio.get(2)) {
				split2[1] = split[0];
			}else if(arrayPunteggio.get(1)>arrayPunteggio.get(0)&&arrayPunteggio.get(1)>arrayPunteggio.get(2)) {
				split2[1] = split[0];
			}else {
				split2[1] = split[0];
			}

		}

		
		//imposto lblWinner
		for(int i = 0; i<split2.length; i++) {
			vincitore += split2[i] + " ";
		}

		//nessun vincitore:
		if(split.length==2){
			if(arrayPunteggio.get(0)== 0 && arrayPunteggio.get(1) == 0){
				lblWinner.setText("NESSUN VINCITORE!");
			}
		}else if(split.length==3) {
			if(arrayPunteggio.get(0)== 0 && arrayPunteggio.get(1) == 0 && arrayPunteggio.get(2) ==0){
				lblWinner.setText("NESSUN VINCITORE!");
			}
		}else {
			lblWinner.setText(vincitore);
		}
	}

		@FXML
		private void indietro(ActionEvent event) throws IOException {
			Parent root = FXMLLoader.load(getClass().getResource("/javafxproject/fxml/PrincipalMenu.fxml"));
			Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
			Scene scene = new Scene(root,600,650);
			window.setScene(scene);
			window.show();
		}
	}