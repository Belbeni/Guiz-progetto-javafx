package javafxproject.Controller;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.stage.Stage;
import javafxproject.Domanda;

public class ImportController {

	@FXML
	private Label lblDifficulty;

	@FXML
	private ListView<String> ListaDomande = new ListView<String>();

	private ObservableList<String> righeFile =FXCollections.observableArrayList();//per popolare la listView
	private  ArrayList<Domanda>righeImportDomanda;
	private ArrayList<String>righeImport;
	private String nomeFile;
	private ArrayList<Domanda> righe;//righe file della difficolt� selezionata in precedernza
	private ArrayList<String> stringRighe;
	//Imposto la listView:
	public void file(ArrayList<Domanda> righeImportDomanda, ArrayList<String> righeImport, ArrayList<Domanda> righe,ArrayList<String> stringRighe,String nomeFile) {
		String s = "";
		for(int i = 0; i<righeImportDomanda.size(); i++) {
			s = righeImportDomanda.get(i).toString();
			righeFile.add(s);
		}

		this.righeImportDomanda = righeImportDomanda;
		this.righeImport = righeImport;

		this.righe= righe;
		this.nomeFile = nomeFile;
		System.out.println(nomeFile);
		this.stringRighe = stringRighe;
		Domanda d = null;

		ListaDomande.setItems(righeFile);

	}

	//carico le domande del file selezionato nella lista:
	private void loadList() {
		String s = "";
		for(int i = 0; i<righeImportDomanda.size(); i++) {
			s = righeImportDomanda.get(i).toString();
			righeFile.add(s);
		}
		ListaDomande.setItems(righeFile);
	}

	public void initialize(URL location, ResourceBundle resources) {
		loadList();
	}


	@FXML
	private void importaSelezionato(ActionEvent event) {
		//Ricavo l'indice della domanda selezionata nella lista:
		int index = ListaDomande.getSelectionModel().getSelectedIndex();

		//Salvataggio domanda selezionata nell'arrayList stringRighe:
		String selezionato = righeImport.get(index);
		stringRighe.add(selezionato);
		for(int i = 0; i<stringRighe.size(); i++){
			System.out.println(stringRighe.get(i));
		}

		//riscrivo il file:
		PrintWriter outStream = null;
		try {
			outStream = new PrintWriter( new FileOutputStream(nomeFile,false));
		}catch(FileNotFoundException e) {

		}
		for(int i = 0; i<stringRighe.size(); i++){
			if(i<stringRighe.size()-1) {
				outStream.println(stringRighe.get(i));

			}else {
				outStream.print(stringRighe.get(i));
			}
		}
		outStream.close();	

	}

	@FXML
	private void indietro(ActionEvent event) throws IOException {
		try{
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/javafxproject/fxml/GestioneDomande.fxml"));

			Parent root =(Parent) loader.load();
			GestioneDomandeController gestione = loader.getController();
			gestione.file(righe, stringRighe,nomeFile);

			Stage stage=(Stage)((Node)event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
}
