package javafxproject.Controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.concurrent.atomic.AtomicInteger;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class NamePlayerController{

	@FXML
	private Label lblPlayer1;

	@FXML
	private Label lblPlayer2;

	@FXML
	private Label lblPlayer3;

	@FXML
	private TextField NamePlayer1;

	@FXML
	private TextField NamePlayer3;

	@FXML
	private TextField NamePlayer2;
    @FXML
    private Button nextButton;

	//variabili passate dalla classe NuovaPartitaController
	private AtomicInteger giocatori = new AtomicInteger(0);
	private String difficolt� = "";
	private int numeroDomande =0;
	private ChoiceBox difficultyBox;

	private void setFinestra() {

		if(giocatori.get()==1) {
			lblPlayer1.setText("Player 1");
			NamePlayer2.setVisible(false);
			NamePlayer3.setVisible(false);
			
	
		}else if(giocatori.get()==2) {
			lblPlayer1.setText("Player 1");
			lblPlayer2.setText("Player 2");
			NamePlayer3.setVisible(false);

		}else if(giocatori.get()==3) {
			lblPlayer1.setText("Player 1");
			lblPlayer2.setText("Player 2");
			lblPlayer3.setText("Player 3");				
		}
	}
	
	public void informazioniPartita(AtomicInteger nGiocatori, String sDifficolt�,int nDomande, ChoiceBox difficultyBox) {
		giocatori =nGiocatori;
		difficolt� = sDifficolt�; 	
		numeroDomande = nDomande;
		this.difficultyBox = difficultyBox;
		
		setFinestra();
	}	

	@FXML
	private	void GoBack(ActionEvent event) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("/javafxproject/fxml/NuovaPartita.fxml"));
		Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
		Scene scene = new Scene(root,600,650);
		window.setScene(scene);
		window.show();
	}

	@FXML
	private	void NextAction(ActionEvent event) {
		//Salvo i nomi dei giocatori in una stringa 
		String nomi = NamePlayer1.getText();

		if(giocatori.get()==2) {
			nomi+="/"+NamePlayer2.getText();
		}else if(giocatori.get()==3) {
			nomi+= "/" + NamePlayer2.getText() + "/" + NamePlayer3.getText();
		}
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/javafxproject/fxml/IniziaPartita.fxml"));
			Parent root =(Parent) loader.load();

			IniziaPartitaController iniziaPartita = loader.getController();
			iniziaPartita.informazioniPartita( giocatori,  difficolt�,numeroDomande, nomi);

			Stage stage=(Stage)((Node)event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@FXML
	private void closeApp(ActionEvent event) {
		System.exit(0);
	}
}