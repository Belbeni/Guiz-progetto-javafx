package javafxproject.Controller;

import java.io.IOException;
import javafxproject.MainApp;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import static javafx.scene.control.Alert.AlertType.CONFIRMATION;
import javafx.scene.control.ButtonType;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafxproject.MainApp;

/**
 *
 * @author belbeni
 */
public class PrincipalMenuController implements Initializable{

	private MainApp main;
	@FXML
	private Parent rootPane;

	@Override
	public void initialize(URL location, ResourceBundle resources) {

	}

	//Questo metodo inizia la parita di gioco  
	public void NuovaPartita(ActionEvent event) throws Exception{
		Parent root2 = FXMLLoader.load(getClass().getResource("/javafxproject/fxml/NuovaPartita.fxml"));
		Scene sceneNuovaPartita = new Scene(root2,600,650);
		Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
		window.setScene(sceneNuovaPartita);
		window.show();
	}

	//Questo metodo apre il pannello impostazioni
	@FXML
	private void Impostazioni(ActionEvent event) throws IOException{
		Parent root3 = FXMLLoader.load(getClass().getResource("/javafxproject/fxml/Impostazioni.fxml"));
		Scene sceneImpostazioni = new Scene(root3,600,650);
		Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
		window.setScene(sceneImpostazioni);
		window.show();

	}

	//Questo metodo apre il pannello di configurazioni    
	@FXML
	private void Configurazioni(ActionEvent event) throws Exception{
		Parent root4 = FXMLLoader.load(getClass().getResource("/javafxproject/fxml/Login.fxml"));
		Scene sceneLogin = new Scene(root4,600,650);
		Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
		window.setScene(sceneLogin);
		window.show();
	}

	//Questo metodo apre il pannello credits 
	@FXML
	private void Credits(ActionEvent event) throws Exception{
		Parent root6 = FXMLLoader.load(getClass().getResource("/javafxproject/fxml/Credits.fxml"));
		Scene sceneCredits = new Scene(root6,600,650);
		Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
		window.setScene(sceneCredits);
		window.show();
	}

	//Questo metodo chiude la finestra
	@FXML
	private void closeApp(ActionEvent event){
		String selection = null;
		Alert alert = new Alert(AlertType.CONFIRMATION, "Delete" +selection+ "?",ButtonType.OK,ButtonType.CANCEL);
		alert.setTitle("Warning");
		alert.setHeaderText(null);
		alert.setContentText("Sei sicuro di voler uscire?");
		alert.showAndWait();
		if(alert.getResult() == ButtonType.OK){
			System.exit(0);
		}else{
			
		}

	}
}
