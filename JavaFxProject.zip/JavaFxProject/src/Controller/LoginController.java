package javafxproject.Controller;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 *
 * @author belbeni
 */
public class LoginController implements Initializable{
    
    @FXML
    private Label  lblStatus;
    @FXML
    private TextField txtUtente;
    @FXML
    private TextField txtPassword;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
       
    }
    public void ModificaConfigurazioni(ActionEvent event) throws Exception{
        if(txtUtente.getText().equals("Admin") && txtPassword.getText().equals("javafx")){
            lblStatus.setText("Login Riuscito");
            Parent root5 = FXMLLoader.load(getClass().getResource("/javafxproject/fxml/Configurazioni.fxml"));
            Scene sceneConfigurazioni = new Scene(root5,600,650);
            Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
            window.setScene(sceneConfigurazioni);
            window.show();
            
        }else{
            lblStatus.setText("Username o Password sbagliato");
        }
    }
     
    @FXML
    private void TornaPrincipalMenu(ActionEvent event) throws Exception{
        Parent root = FXMLLoader.load(getClass().getResource("/javafxproject/fxml/PrincipalMenu.fxml"));
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root,600,650);
            window.setScene(scene);
            window.show();
    }
    
}
