package javafxproject.Controller;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Random;
import java.util.ResourceBundle;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicIntegerArray;

import com.sun.xml.internal.bind.v2.runtime.unmarshaller.Loader;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableView;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafxproject.Domanda;

/**
 *
 * @author belbeni
 */
public class IniziaPartitaController implements Initializable{

	//variabili passate dalla classe NamePlayerController
	private AtomicInteger giocatori = new AtomicInteger(0);
	private String difficolt� = "";
	private int numeroDomande =0;
	private String nomi;
	public void informazioniPartita(AtomicInteger nGiocatori, String sDifficolt�,int nDomande,String nomi) {
		giocatori =nGiocatori;
		difficolt� = sDifficolt�; 	
		numeroDomande = nDomande;
		this.nomi = nomi;
	}

	private ArrayList<String> righeFile = new ArrayList<String>();
	private ArrayList<Domanda> infoGioco = new ArrayList<Domanda>();
	private AtomicInteger g = new AtomicInteger(1);
	private AtomicInteger punteggio =  new AtomicInteger(0);
	private AtomicInteger turno = new AtomicInteger(1);
	private AtomicIntegerArray arrayPunteggio = new AtomicIntegerArray(new int[giocatori.get()]);
	private AtomicInteger giocatore_attuale = new AtomicInteger(0);
	private AtomicInteger punteggio_attuale = new AtomicInteger(0);

	@Override
	public void initialize(URL location, ResourceBundle resources) {

	}

	//Lettura file della difficolt� selezionata:
	public void letturaFile(String difficolt�) throws IOException {
		BufferedReader lettore = null;

		try
		{
			lettore = new BufferedReader(new FileReader(difficolt�));
		}
		catch(FileNotFoundException e)
		{
			System.exit(0);
		}
		String r =null;
		try 
		{
			r = lettore.readLine();
		} 
		catch (IOException e) 
		{
			System.exit(0);
		}

		while(r!=null)
		{
			righeFile.add(r);
			try 
			{
				r = lettore.readLine();
				System.out.println(r);

			}
			catch (IOException e)
			{
				System.exit(0);
			}
		}
		lettore.close();

	}

	@FXML
	private void StartGame(ActionEvent event) throws Exception{
		
		//Se la difficolt� � mista, carico nell'arrayList righeFile tutti i file di testo:
		if(difficolt�.equalsIgnoreCase("mista")) {
			String nomeFile;

			//Carico Facile.txt
			nomeFile = "src/javafxproject/txt/Facile.txt";
			letturaFile(nomeFile);

			//Carico Media.txt
			nomeFile = "src/javafxproject/txt/Media.txt";
			letturaFile(nomeFile);

			//Carico Difficile.txt
			nomeFile = "src/javafxproject/txt/Difficile.txt";
			letturaFile(nomeFile);

		}else {
			letturaFile(difficolt�);
		}
		
		AtomicIntegerArray arrayPunteggio = new AtomicIntegerArray(new int[giocatori.get()]);
		getDomande(righeFile, infoGioco);
		Domanda domandaEstratta = new Domanda(" "," / / / "," ");

		if(estraiDomanda(infoGioco, domandaEstratta)){
			try {
				AtomicIntegerArray prov = new AtomicIntegerArray(new int[giocatori.get()]);
				FXMLLoader loader = new FXMLLoader(getClass().getResource("/javafxproject/fxml/StartGame.fxml"));
				Parent root =(Parent) loader.load();

				//passaggio delle variabili utili per la finestra di gioco da NuovaPartitaController a StartgameController:
				StartGameController startGame = loader.getController();
				startGame.finestra(infoGioco,  domandaEstratta,righeFile, giocatori,  numeroDomande, nomi, 0,arrayPunteggio);

				Stage stage=(Stage)((Node)event.getSource()).getScene().getWindow();
				stage.setScene(new Scene(root));
				stage.show();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		else
		{
			//finestra alert che avverte che le domande sono esaurite
			Alert alert = new Alert(AlertType.ERROR);
			alert.setTitle("Errore");
			alert.setHeaderText("Domande Esaurite");
			alert.setContentText("Non ci sono più domande da estrarre.");

			alert.showAndWait();
		}

	}

	//Metodo per ottenere il testo della domanda/opzioni/risposta giusta
	public void getDomande (ArrayList<String> righeFile, ArrayList<Domanda> infoGioco)
	{
		Domanda d = null;
		for(int i = 0;i<righeFile.size(); i++)
		{
			String[] opzioni = righeFile.get(i).split(",");
			d = new Domanda(opzioni[0], opzioni[1],opzioni[2]);    
			infoGioco.add(d);
		} 
	}

	//Estrazioni domande
	public Boolean estraiDomanda(ArrayList<Domanda> infoGioco,Domanda domandaEstratta)
	{
		//estrazione domanda casuale:
		Random r = new Random();
		int num = 0;
		int nDomande = infoGioco.size();
		System.out.println(nDomande);
		if(nDomande > 0)
		{
			num = r.nextInt(nDomande);

			domandaEstratta.setTesto(infoGioco.get(num).getTesto());
			domandaEstratta.setPossibiliRisposte(infoGioco.get(num).getPossibiliRisposte());
			domandaEstratta.setRispostaEsatta(infoGioco.get(num).getRispostaEsatta()); 
			//rimozione della domanda estratta dall'elenco
			infoGioco.remove(num);
			return true;
		}
		else
		{
			//Ritorna FALSE perché non ha trovato domande disponibili
			return false;
		}
	}

	@FXML
	private void TornaPrincipalMenu(ActionEvent event) throws Exception{
		Parent root = FXMLLoader.load(getClass().getResource("/javafxproject/fxml/PrincipalMenu.fxml"));
		Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
		Scene scene = new Scene(root,600,650);
		window.setScene(scene);
		window.show();
	}

	@FXML
	private void TornaNuovaPartita(ActionEvent event) throws Exception{
		Parent root2 = FXMLLoader.load(getClass().getResource("/javafxproject/fxml/NuovaPartita.fxml"));
		Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
		Scene sceneNuovaPartita = new Scene(root2,600,650);
		window.setScene(sceneNuovaPartita);
		window.show();
	}

	//Questo metodo chiude la finestra
	@FXML
	private void closeApp(ActionEvent event){
		System.exit(0);
	}
}