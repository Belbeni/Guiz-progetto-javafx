package javafxproject.Controller;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;
import javafxproject.Domanda;

public class GestioneDomandeController {

	@FXML
	private Label lblDifficulty;

	@FXML
	private ListView<String> ListaDomande = new ListView<String>();

	private ObservableList<String> righeFile =FXCollections.observableArrayList();//per popolare la listView
	private  ArrayList<Domanda>righe;
	private ArrayList<String>stringRighe;
	private String nomeFile;

	/**
	 * 
	 *SCELTA SU COME MODIFICARE I FILE
	 * 
	 */

	//valori passati dalla finestra precendete:
	public void file(ArrayList<Domanda> righe,ArrayList<String> stringRighe,String nomeFile) {
		this.nomeFile = nomeFile;
		String s = "";
		for(int i = 0; i<righe.size(); i++) {
			s = righe.get(i).toString();
			righeFile.add(s);
		}

		this.righe = righe;
		this.stringRighe = stringRighe;

		Domanda d = null;

		//lblDifficulty
		String[] split = nomeFile.split("/");
		lblDifficulty.setText(split[split.length-1]);

		ListaDomande.setItems(righeFile);

	}

	//carico le domande del file selezionato nella lista:
	private void loadList() {
		String s = "";
		for(int i = 0; i<righe.size(); i++) {
			s = righe.get(i).toString();
			righeFile.add(s);
		}
		ListaDomande.setItems(righeFile);
	}

	public void initialize(URL location, ResourceBundle resources) {
		loadList();
	}

	@FXML
	private void CreaNuovaDomanda(ActionEvent event) throws IOException {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/javafxproject/fxml/EditorDomande.fxml"));
			Parent root =(Parent) loader.load();
			EditorDomandeController controllo = loader.getController();
			controllo.controlloAzione( 0, 0, stringRighe,righe,nomeFile,null);

			Stage stage=(Stage)((Node)event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@FXML
	private void EliminaDomanda(ActionEvent event) {		
		//Ottengo l'indice della domanda selezionata:
		int index = ListaDomande.getSelectionModel().getSelectedIndex();
		righe.remove(index);
		stringRighe.remove(index);

		//Imposto la ListView:
		String s = "";
		for(int i = 0; i<righe.size(); i++) {
			s = righe.get(i).toString();
			righeFile.add(s);
		}
		ListaDomande.setItems(righeFile);

		//Riscrivo il  file:
		PrintWriter outStream = null;
		try {
			outStream = new PrintWriter( new FileOutputStream(nomeFile,false));
		}catch(FileNotFoundException e) {

		}
		for(int i = 0; i<stringRighe.size(); i++){
			if(i<stringRighe.size()-1) {
				outStream.println(stringRighe.get(i));

			}else {
				outStream.print(stringRighe.get(i));
			}
		}
		outStream.close();	
	}

	@FXML
	private void ModificaDomanda(ActionEvent event) {
		try {
			//Ricavo l'indice della domanda selezionata nella lista:
			int index = ListaDomande.getSelectionModel().getSelectedIndex();

			//Ricavo la domanda selezionata:
			String selezionato = stringRighe.get(index);


			FXMLLoader loader = new FXMLLoader(getClass().getResource("/javafxproject/fxml/EditorDomande.fxml"));
			Parent root =(Parent) loader.load();
			EditorDomandeController controllo = loader.getController();
			controllo.controlloAzione( 1,index, stringRighe,righe,nomeFile,selezionato);

			Stage stage=(Stage)((Node)event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}


	@FXML
	private void importa(ActionEvent event) throws IOException {
		//lettura ile import.txt
		ArrayList<String> righeImport = new ArrayList<String>();
		ArrayList<Domanda> righeImportDomanda = new ArrayList<Domanda>();
		BufferedReader lettore = null;

		try
		{
			lettore = new BufferedReader(new FileReader("src/javafxproject/txt/import.txt"));
		}
		catch(FileNotFoundException e)
		{
			System.exit(0);
		}
		String r =null;
		try 
		{
			r = lettore.readLine();
		} 
		catch (IOException e) 
		{
			System.exit(0);
		}

		while(r!=null)
		{
			righeImport.add(r);
			try 
			{
				r = lettore.readLine();
			}
			catch (IOException e)
			{
				System.exit(0);
			}
		}	
		lettore.close();

		Domanda d = null;
		for(int i = 0;i<righeImport.size(); i++)
		{
			String[] opzioni = righeImport.get(i).split(",");
			d = new Domanda(opzioni[0], opzioni[1],opzioni[2]);    
			righeImportDomanda.add(d);
		} 

		//vado in ImportController
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/javafxproject/fxml/Import.fxml"));
			Parent root =(Parent) loader.load();
			ImportController controller = loader.getController();
			controller.file(righeImportDomanda, righeImport, righe, stringRighe,nomeFile);

			Stage stage=(Stage)((Node)event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@FXML
	private  void esporta(ActionEvent event) throws IOException {
		int index = ListaDomande.getSelectionModel().getSelectedIndex();

		//Ricavo la domanda selezionata:
		String selezionato = stringRighe.get(index);
		System.out.println(selezionato);
		
		//inserisco la domanda selezionata nel file export.txt
		PrintWriter outStream = null;
		try {
			outStream = new PrintWriter( new FileOutputStream("src/javafxproject/txt/export.txt",true));
		}catch(FileNotFoundException e) {

		}
		outStream.println(selezionato);
		outStream.close();	
		
		Alert alert = new Alert(AlertType.ERROR);
		alert.setTitle("");
		alert.setHeaderText(null);
		alert.setContentText("Modifiche a export.txt apportate");
		alert.showAndWait();
	}

	@FXML
	private   void indietro(ActionEvent event) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("/javafxproject/fxml/Configurazioni.fxml"));
		Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
		Scene scene = new Scene(root,600,650);
		window.setScene(scene);
		window.show();
	}
}