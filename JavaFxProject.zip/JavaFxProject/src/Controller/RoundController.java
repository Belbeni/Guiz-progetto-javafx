package javafxproject.Controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicIntegerArray;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import javafxproject.Domanda;

public class RoundController {

	@FXML
	private Label lblPlayer1;

	@FXML
	private Label lblPlayer2;

	@FXML
	private Label lblPlayer3;

	private ArrayList<Domanda> infoGioco;
	private Domanda domandaEstratta;
	private ArrayList<String> righeFile;
	private AtomicInteger giocatori;
	private int numeroDomande;
	private AtomicInteger turno = new AtomicInteger(1);
	private AtomicInteger giocatore_attuale = new AtomicInteger(1);
	private AtomicIntegerArray arrayPunteggio;
	private AtomicInteger punteggio;
	private String nomi;
	private int n;

	//VALORI PASSATI DALLA FINESTRA INIZIAPARTITACONTROLLER:
	public void finestra(ArrayList<Domanda>infoGioco, Domanda domandaEstratta,ArrayList<String> righeFile,AtomicInteger giocatori, int numeroDomande,String nomi,AtomicIntegerArray arrayPunteggio,int n) {
		this.infoGioco = infoGioco;
		this.domandaEstratta= domandaEstratta;
		this.righeFile = righeFile;
		this.domandaEstratta = domandaEstratta;
		this.giocatori = giocatori;
		this.numeroDomande = numeroDomande;
		this.nomi = nomi;
		int contatore = n;
		contatore++;
		this.n = contatore;
		System.out.println(n);
		this.arrayPunteggio = arrayPunteggio;

		String[] split = nomi.split("/");
		int p = 0;

		//aggiungo 10 punti se tutte le domande date sono giuste
		if(n==0) {
			if(arrayPunteggio.get(0) ==numeroDomande){
				p =arrayPunteggio.getAndIncrement(0)+10;
				arrayPunteggio.set(0,p);
			}
			if(split.length==2){
				if(arrayPunteggio.get(1) ==numeroDomande){
					p =arrayPunteggio.getAndIncrement(1)+10;
					arrayPunteggio.set(1,p);
				}
			}	}else if(split.length==3) {

				if(arrayPunteggio.get(1) ==numeroDomande){
					p =arrayPunteggio.getAndIncrement(1)+10;
					arrayPunteggio.set(1,p);
				}
				if(arrayPunteggio.get(2) ==numeroDomande){
					p =arrayPunteggio.getAndIncrement(2)+10;
					arrayPunteggio.set(2,p);
				}
			}

		lblPlayer1.setText(split[0] + " " + String.valueOf(arrayPunteggio.get(0)));

		if(split.length==2){
			lblPlayer2.setText(split[1] + " " + String.valueOf(arrayPunteggio.get(1)));
		}else if(split.length==3) {
			lblPlayer2.setText(split[1] + " " + String.valueOf(arrayPunteggio.get(1)));
			lblPlayer3.setText(split[2] + " " + String.valueOf(arrayPunteggio.get(2)));
		}
	}



	@FXML
	private void nextRound(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/javafxproject/fxml/StartGame.fxml"));
			Parent root =(Parent) loader.load();

			StartGameController startGame = loader.getController();
			startGame.finestra(infoGioco,  domandaEstratta,righeFile, giocatori,  numeroDomande, nomi, n, arrayPunteggio);

			Stage stage=(Stage)((Node)event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
}

