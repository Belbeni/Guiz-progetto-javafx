/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxproject.Controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 *
 * @author belbeni
 */
public class ImpostazioniController implements Initializable{
    
    //panello impostazioni variabili
    @FXML
    private Button salvaBtn;
    @FXML
    private RadioButton suonoSiBtn;
    
    @FXML
    private ToggleGroup suono;
    
    @FXML
    private RadioButton suonoNoBtn;
    
    @FXML
    private RadioButton musicaSiBtn;
     
    @FXML
    private ToggleGroup musica;
    
    @FXML
    private RadioButton musicaNoBtn;

    @Override
    public void initialize(URL location, ResourceBundle resources) {  
    }
    
    @FXML
    private void salvaImpostazioni(ActionEvent event) throws IOException{
        if(suonoNoBtn.isSelected() || suonoSiBtn.isSelected()){
             Parent root = FXMLLoader.load(getClass().getResource("/javafxproject/fxml/PrincipalMenu.fxml"));
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root,600,650);
            window.setScene(scene);
            window.show(); 
        }    
    }
    
    //Questo metodo torna indietro
    @FXML
    private void TornaPrincipalMenu(ActionEvent event) throws Exception{
        Parent root = FXMLLoader.load(getClass().getResource("/javafxproject/fxml/PrincipalMenu.fxml"));
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root,600,650);
            window.setScene(scene);
            window.show();
    }
  
    @FXML
    private void closeApp(ActionEvent event){
        System.exit(0);
    }
}